exports.config = {
  paths: {
    public: '.',
  },
  files: {
    javascripts: {
      joinTo: 'output.js',
    },
  },
};
